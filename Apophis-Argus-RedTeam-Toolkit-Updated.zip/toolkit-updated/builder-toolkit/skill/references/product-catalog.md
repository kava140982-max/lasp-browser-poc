# Apophis Lighthouse Builder — Produktkatalog in einfacher Sprache

> **Status:** vorhandener lokaler Modulbaukasten plus v2-Harmonisierungsentwurf. Nicht zertifiziert; kein produktionssicheres oder normkonformes System. Der Inhalt von v2 wurde aus der gelieferten Spezifikation übernommen, nicht extern verifiziert.

## Kurz erklärt

Der Builder hilft Teams, wiederkehrende Beratungs- und Governance-Module planvoll zu beschreiben: Was darf das Modul? Welche Daten verarbeitet es? Wann muss es stoppen? Wer prüft den Vorschlag? Welche Tests und Belege liegen tatsächlich vor? Es liefert Vorlagen, einen Scaffold-Generator, Validatoren und einen lokalen synthetischen Testlauf. Es entscheidet nicht anstelle von Fachleuten und führt keine produktive Aktion aus.

## Lieferumfang

| Bestandteil | Was es in Alltagssprache tut | Stand |
|---|---|---|
| Skill-Anleitung (Markdown und JSON) | Schrittfolge, Sicherheitsregeln, Grenzen und Antwortformat | v1-Anleitung erweitert um v2-Draft; beide Markdownkopien und JSON-Fassung werden synchron gehalten |
| Modul-Scaffolder | Legt ein kleines Beispielprojekt mit Schema, Policy, Test und Katalogeintrag an | vorhanden; wird lokal smoke-getestet |
| Assurance-Runner | Prüft Dateien/JSON und führt vorhandene lokale Tests sowie synthetisches Labor aus | vorhanden; externe Reviews bleiben ausstehend |
| Modul-/Katalogvalidator | Prüft Manifestfelder, IDs, Pfade, Reifegradangaben und unzulässige Claims | vorhanden |
| Generatoren | Erstellen Katalog, Hashmanifest und unsignierte Provenance-Datei | vorhanden; Hash/Provenance ist keine Signatur oder Sicherheitsgarantie |
| Vorlagen und Beispiele | Verträge, Testfälle, Plattformfixtures und Beispielmodule | enthalten; synthetisch |
| Global-Harmonisierung v2 | Architekturvorschlag, Gate-Sequenz, Registry, Profile, Lücken und Fahrplan | Draft, unsigniert, noch nicht implementiert/extern geprüft |
| Dashboard HTML und kanonisches JSON | Lesbare und maschinenlesbare Darstellung des v2-Entwurfs | aus Nutzerdatei übernommen; eingebettete Standards nicht extern verifiziert |

## Stand und Reifegrad

- **Vorhanden im Paket:** bestehender lokaler Builder, Skripte, Templates, Beispiele und synthetische Plattformtests.
- **In dieser Aufwertung:** v2-Spezifikation, referenzierte Skill-Ergänzung, Produktkatalog in einfacher Sprache sowie Test-/Konsistenznachweise.
- **Nicht gleichbedeutend mit Implementierung:** 16 Gates, Normzuordnungen, Signierung, SBOM/VEX, Policy-as-Code, kryptografische Identitätsprüfung, souveränes Routing und sektorale Akkreditierung. Diese sind in v2 geplante Kontrollbereiche bzw. Gaps.
- **Nicht ausgeführt:** externe Identitätsprovider- oder Signaturprüfung, unabhängiges Security-/Domain-/Red-Team-Review, produktive Integration, Feld-/Labortest und Zertifizierung.
- **Evidenzsprache:** `PASS` gilt nur für den konkret gelaufenen lokalen Test. `PASS_WITH_LIMITATIONS` bedeutet, dass Einschränkungen/offene Prüfungen bleiben. `NOT_EXECUTED` ist kein Pass.

## Für wen und wofür geeignet?

| Einsatz | Möglicher Nutzen | Grenzen |
|---|---|---|
| Governance und Nachweisführung | Rollen, Verantwortlichkeiten, Freigaben und Beleglisten strukturieren | ersetzt weder Audit noch Rechtsberatung |
| Software-Lieferkette/Release | SBOM-, Herkunfts-, Signatur- und Abhängigkeitskontrollen als Plan erstellen | v2 beschreibt Lücken; nicht alle Integrationen sind implementiert |
| KI-Modell- und Agenten-Governance | Human Review, Modellroute, Unsicherheit und Tool-Grenzen dokumentieren | keine Garantie gegen Prompt Injection oder Fehlentscheidungen |
| Datenschutz und regulierte Daten | Datenklassen, Minimierung, Route und Stop-Bedingungen vorstrukturieren | keine echte Datenschutz- oder Rechtsprüfung |
| KRITIS/OT und sicherheitskritische Systeme | Scope, Change Control und Betreiberpflichten als Kontrollplan ordnen | nur vorbereitend; keine Freigabe für Betrieb/Steuerung |
| Finanz-/Resilienzprozesse | Drittanbieter-, Vorfall- und Kontrollnachweise strukturieren | kein regulatorisches Mapping ohne Primärquellenprüfung |
| Gesundheit, GxP, Life Sciences | Review- und Evidenzartefakte entwerfen | keine klinischen Entscheidungen, Bio-Operationalisierung oder Validierung |
| Internationale Organisationen/Identität/PQC | Profile und offene Prüfpunkte zusammenführen | kein Akkreditierungs-, Vertrauensdienst- oder PQC-Nachweis |

## Vollständige Domänenprofile aus der v2-Vorlage

Die folgenden 13 Profile sind **Themenprofile im Entwurf**, keine angebotenen zertifizierten Produkte:

- **General High Assurance** (`general-high-assurance`, Risiko `R1–R2`): Governance-, Evidence-, Supply-Chain- und Verwaltungssoftware. Unabhängige Freigabe für externe Wirkung, Signierung, Löschung und Veröffentlichung. 
- **Financial Services Resilience (Banken, Zahlung, FMI)** (`financial-services-resilience`, Risiko `R3`): Banken, Versicherer, Wertpapierfirmen, Zahlungsdienstleister, FMIs. ICT-Risikomanagement, Vorfallsmeldung, Resilienztest, Drittanbieterregister. 
- **Internationale Organisationen (UN, NATO, OSZE, Rotes Kreuz)** (`public-international-organizations`, Risiko `R3–R4`): Multilaterale Governance, Friedens- und Hilfseinsätze, klassifizierte Umgebungen. Hohe Akkreditierungs- und Kennzeichnungspflichten. 
- **KRITIS / Öffentliche Infrastruktur / OT** (`critical-infrastructure-ot`, Risiko `R4`): Energie, Wasser, Gesundheit, Verkehr, Telekommunikation, Verwaltung. Asset-Scope, Betreiberverantwortung, Change Control, Lieferkettennachweis. 
- **Privacy / Regulated Data** (`privacy-regulated-data`, Risiko `R3`): Personenbezogene, Gesundheits- und besonders geschützte Daten. Zweckbindung, Minimierung, Zugriffskontrolle, Aufbewahrung, Export-/Löschkonzept. 
- **Life Sciences / Biosecurity** (`life-sciences-biosecurity`, Risiko `R3–R4`): Biologische, medizinische, klinische Domänen. Nur nicht-operative, hochrangige Planung und Evidenzbewertung. 
- **Medizinprodukte / GxP / klinische Systeme** (`medical-device-regulated`, Risiko `R3–R4`): SaMD, klinische Entscheidungsunterstützung, Laborsysteme. Computervalidierung, Datenintegrität, Audit Trail. 
- **AI Model Governance / GPAI** (`ai-model-governance`, Risiko `R2–R3`): Modellbewertung, Red-Teaming, Bias-, Robustheits- und Dokumentationsprüfung für KI- und GPAI-Systeme. 
- **Agentic AI / Multi-Agent-Systeme** (`agentic-ai`, Risiko `R3`): Autonome oder teilautonome Agenten mit Tool-Zugriff. Begrenzung von Agency, Berechtigungen und Seiteneffekten. 
- **Sovereign Identity & Trust Services** (`sovereign-identity-trust`, Risiko `R3`): Nationale und europäische Vertrauensdienste, Wallet-Integration, qualifizierte Signaturen und Siegel. 
- **Quantum Readiness / Crypto-Agility** (`quantum-readiness`, Risiko `R2–R3`): Vorbereitung auf PQC-Migration: Krypto-Inventar, Hybrid-Übergang, Agilitätsnachweis, Rotationsplanung. 
- **Software Supply Chain & Release** (`software-supply-chain`, Risiko `R2`): SBOM, Provenance, Signierung, Verifikation beim Konsumenten, Drittanbieter- und Abhängigkeitsmanagement. 
- **Raumfahrt, Maritime, Luftfahrt** (`space-maritime-aviation`, Risiko `R4`): Sicherheitskritische Systeme mit Zertifizierungspflicht und langen Lebenszyklen. Nur vorbereitende Bewertung. 

## Register und Arbeitsbestand

Die gelieferte v2-JSON enthält **70 Registry-Einträge** in diesen 21 Themenfamilien: 
`Agentic AI`, `Audit`, `Datenschutz`, `Finanz`, `Funktionale Sicherheit`, `Gesundheit`, `Identität`, `Informationssicherheit`, `Internationale Organisationen`, `KI-Governance`, `Kryptografie`, `OT / KRITIS`, `Observability`, `Resilienz`, `Risikomanagement`, `Secure Development`, `Sektor`, `Supply Chain`, `Verteidigung`, `Vertrag`, `Zertifizierung`.

Die Vorlage listet **37 offene Gaps**. Das sind zu prüfende Aussagen aus dem Entwurf, nicht durch uns bestätigte Defizite oder Ergebnisse:

| ID | Offener Punkt laut Entwurf | Priorität | Aufwand laut Entwurf (Personentage) |
|---|---|---:|---:|
| `G-01` | Provenance ist unsigniert — keine verifizierbare Herkunft | crit / P1 | 6 |
| `G-02` | Kein SBOM-Emitter (CycloneDX / SPDX) | crit / P1 | 8 |
| `G-03` | Keine VEX-/CSAF-Triage für bekannte Schwachstellen | high / P1 | 6 |
| `G-04` | Kein SAST / SARIF-Import | high / P1 | 5 |
| `G-05` | Kein Abhängigkeits- und Schwachstellenscan (OSV) | high / P1 | 4 |
| `G-06` | Kein OpenSSF Scorecard-Gate | medium / P1 | 3 |
| `G-07` | Gate-Logik ist hartkodiert statt Policy-as-Code | crit / P2 | 14 |
| `G-08` | Keine Crypto-Agilität und kein PQC-Profil | high / P3 | 9 |
| `G-09` | Keine überprüfbare Identitätsbindung (VC / SPIFFE / OIDC) | high / P3 | 12 |
| `G-10` | JSON-Schemas existieren, werden aber nicht durchgesetzt | high / P1 | 4 |
| `G-11` | Kein Fuzzing, Property-based oder Mutation Testing | medium / P2 | 7 |
| `G-12` | KI-spezifische Angriffsfläche nicht systematisch abgedeckt | high / P2 | 10 |
| `G-13` | Keine Model-Card / AIBOM / Dataset-Dokumentation | high / P2 | 6 |
| `G-14` | Kein maschinenlesbarer Standards-Crosswalk | crit / P0 | 10 |
| `G-15` | Kein unveränderbarer externer Evidence Store | medium / P5 | 8 |
| `G-16` | Kein Schlüssel- und Issuer-Lebenszyklus | medium / P3 | 6 |
| `G-17` | Kein Vorfallmanagement-Vertrag mit Meldelinien und Fristen | high / P4 | 9 |
| `G-18` | Keine Resilienz- und Kontinuitätsartefakte | medium / P4 | 7 |
| `G-19` | Kein ICT-Drittanbieterregister | medium / P4 | 5 |
| `G-20` | Keine Vertraulichkeitslabel mit kryptografischer Bindung | medium / P3 | 7 |
| `G-21` | Audit-Ausgaben nicht mehrsprachig und nicht barrierefrei | low / P5 | 4 |
| `G-22` | Kein reproducible Build und keine SLSA-Level-Verifikation | medium / P2 | 8 |
| `G-23` | Kill-Switch, Heartbeat und Budget-Grenzen sind nicht implementiert | high / P2 | 6 |
| `G-24` | Keine Multi-Tenant-Isolations-Referenzimplementierung | medium / P3 | 9 |
| `G-25` | Keine Unsicherheitsquantifizierung oder Kalibrierung | medium / P2 | 7 |
| `G-26` | Kein Mapping zu funktionaler Sicherheit (SIL / ASIL) | medium / P4 | 6 |
| `G-27` | Kein Exportkontroll- und Sanktionsscreening | medium / P4 | 5 |
| `G-28` | Keine Agent-Interoperabilität (MCP / A2A) | high / P4 | 10 |
| `G-29` | Katalog ist nicht signiert und nicht versioniert | high / P1 | 5 |
| `G-30` | Keine Telemetrie- und Observability-Verträge | medium / P2 | 5 |
| `G-31` | Keine Lizenz-Compliance-Prüfung | low / P1 | 3 |
| `G-32` | Kein Datenresidenz- und Souveränitätsrouting | medium / P3 | 6 |
| `G-33` | Menschliche Freigabe ist nicht als Systemprozess verankert | crit / P2 | 9 |
| `G-34` | Kein Pfad zu unabhängiger Bewertung oder Akkreditierung | medium / P5 | 12 |
| `G-35` | Evidenz hat keine Frische und kein Verfallsdatum | medium / P2 | 4 |
| `G-36` | Determinismus der Modellroute ist nicht nachgewiesen | medium / P2 | 5 |
| `G-37` | Keine SHA-Pinning- und Workflow-Härtungsprüfung | low / P1 | 2 |

Die Summe der genannten Aufwandspunkte wird hier nicht als verbindliches Projektbudget ausgewiesen: Abhängigkeiten, Überschneidungen, Reviewerzeit und externe Beschaffung sind nicht validiert.

## Mögliche Zeitersparnis in Arbeitsstunden

Es liegen keine realen Messungen oder kontrollierten Vorher-nachher-Vergleiche vor. Die folgenden Zahlen sind daher **illustrative Szenarien** für wiederkehrende, gut eingegrenzte interne Module. Sie schätzen primär die eingesparte Strukturierungs- und Dokumentationsarbeit; Fachprüfung, Integrationen, Sicherheitsengineering und externe Audits kommen weiterhin hinzu.

| Wiederkehrende Arbeit an einem einfachen bis mittleren Modul | Möglicher reduzierter manueller Aufwand* | Mögliche Ersparnis* |
|---|---:|---:|
| Anforderungen, Rollen und Traceability strukturieren | 3–8 Std. | 2–5 Std. |
| Ausgangsdateien/Verträge und Beispielmodul erzeugen | 3–7 Std. | 2–5 Std. |
| Synthetische Testfälle und lokale Prüfläufe vorbereiten | 4–10 Std. | 2–6 Std. |
| Bericht, Katalog und Evidenzstatus konsolidieren | 2–6 Std. | 1–4 Std. |
| **Illustrativer Gesamtbereich je wiederkehrendem Modul** | **12–31 Std.** | **7–20 Std.** |

\* Keine Messwerte. Bereiche überschneiden sich und dürfen nicht ohne Prüfung addiert werden. Einmalige Einarbeitung, Anpassung, Debugging und Reviews können Teile der Ersparnis aufzehren. Bei neuartigen/hochriskanten Vorhaben kann die Nettoersparnis null oder negativ sein.

### Rechenbeispiel, keine Zusage

Für 5 ähnliche interne Module könnte ein Team als Hypothese `5 × 7–20 Std. = 35–100 Std.` Brutto-Strukturierungsersparnis ansetzen. Davon sind Einrichtung, lokale Integration und Review abzuziehen; die Zahl ist weder Produktivitätsmessung noch Kosten-/ROI-Versprechen. Zeit der Domänenverantwortlichen und unabhängigen Prüfer wird nicht eingespart.

## Grenzen und Voraussetzungen

- Ergebnisse müssen von benannten Menschen mit passender Fachrolle geprüft werden.
- Für sensible Daten, reale Identitäten, Netzwerkintegrationen oder consequential Entscheidungen braucht es ein konkretes Bedrohungsmodell, sichere Umgebung und ausdrückliche Autorisierung.
- Es wurden im Paket keine realen Kundendaten, Produktionsziele, Identitätsdienste oder externen Kontrollsysteme geprüft.
- Normausgaben, Gesetze und Fristen ändern sich; aktuelle Primärquellen prüfen. Der Katalog ist keine Rechtsberatung.
- Hashes zeigen nur Byte-Identität im angegebenen Scope. Unsignierte Provenance ist keine Attestation.
- Keine Aussage über Sicherheit, Compliance, Akkreditierung, Zertifizierung oder Produktionsreife.

## Vorgeschlagene nächste Schritte laut Fahrplan

- **P0 — Fundament, Verträge und Baseline** (`sofort`): Version v2 einfrieren, Evidenz-Vokabular und Entscheidungsalgebra verbindlich machen, Standards-Crosswalk als zentrales Artefakt etablieren.
- **P1 — Verifizierbarkeit: Signatur, SBOM, VEX, SAST** (`priorisiert`): Aus unsignierten Metadaten werden überprüfbare Attestationen. Der Leuchtturm kann erstmals beweisen, woher er kommt und was in ihm steckt.
- **P2 — Policy-as-Code, KI-Härtung und Observability** (`geplant`): Entscheidungslogik wird extern prüfbar, KI-spezifische Risiken werden messbar, jede Entscheidung wird beobachtbar.
- **P3 — Identität, Souveränität, Crypto-Agilität** (`geplant`): Autorisierung wird kryptografisch überprüfbar, Datenklassen werden an Label und Residenz gebunden, Kryptografie wird austauschbar.
- **P4 — Sektorprofile: Banken · KRITIS · Gesundheit · Internationale Organisationen · Agentic AI** (`geplant`): Der Leuchtturm spricht die Sprache der Sektoren: DORA, NIS2/CRA, MDR/GxP, NATO/UN, IEC 62443, MCP/A2A — jeweils als eigenes, abgrenzbares Profil mit eigenem Crosswalk.
- **P5 — Unabhängige Assurance, Ankerung und Akkreditierungspfad** (`geplant`): Vom intern getesteten Baukasten zum extern überprüfbaren Referenzsystem: unveränderbare Evidenz, OSCAL-Austausch, vorbereitetes Assessment-Paket.
- **P6 — Kontinuierliches Horizon-Scanning und Re-Verifikation** (`dauerhaft`): Der Leuchtturm bleibt aktuell: Normänderungen, neue Profile, Ablauf von Evidenz, Re-Test-Kadenz und Rückzug veralteter Referenzen.

## Ein-Satz-Zusammenfassung

Der Lighthouse Builder ist ein lokaler Bau- und Dokumentationsbeschleuniger mit synthetischen Prüfgerüsten; sein möglicher Wert liegt in wiederverwendbarer Strukturarbeit, während Verantwortung, fachliche Qualität und externe Sicherheits-/Konformitätsnachweise beim zuständigen Team und unabhängigen Stellen bleiben.
