# Maximal Synthetic Platform Lab

Die Plattform unter `examples/maximal-platform/platform.json` ist eine absichtlich überdimensionierte Testmatrix. Sie enthält acht Module und 28 Fälle. Sie testet keinen realen Betrieb, sondern die Wiederverwendbarkeit der Gates.

## Abgedeckte Module

- Evidence-Governance
- Software-Supply-Chain und Release-Provenance
- Privacy-/Regulated-Data-Routing
- Life-Sciences-/Biosecurity-Beratung ohne operative Inhalte
- KRITIS-/Public-Infrastructure-Readiness
- Tenant-Isolation
- Research Integrity / Open Science
- KI-Model-Risk-Review

## Abgedeckte Entscheidungen

- `pending_review`
- `denied`
- `blocked`
- `invalid_request`

## Ausführung

```bash
python scripts/run_platform_lab.py examples/maximal-platform/platform.json
```

Der Runner ist bewusst deterministisch. Er simuliert keine Fachmodelle, keine Identitätsprovider und keine externe Infrastruktur. Ein grüner Lauf beweist nur, dass die synthetische Gate-Matrix die erwarteten Entscheidungen abbildet.
