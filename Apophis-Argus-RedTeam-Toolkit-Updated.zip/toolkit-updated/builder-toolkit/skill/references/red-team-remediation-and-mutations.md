# Red-Team-Remediation und API-Mutationstests

**Verwenden, wenn:** ein Red-Team-/Auditbericht reproduzierte API-, Auth-, Validierungs- oder Datenintegritätsfehler nennt; wenn eine Regression behoben wird; oder wenn ein neuer lokaler/offline Dienst gebaut oder veröffentlicht wird.

## Pflichtablauf

1. **Historischen Zielstand binden.** Erhebe Archiv-/Quellhash, Version/Commit, Dateien, Runtime und Tests. Bewahre Originalarchiv und „vorher“-Quellstand unverändert; führe aktive Probes nur gegen isolierte Kopie, lokale Loopback-Schnittstelle und synthetische Daten aus.
2. **Entdeckungsweg speichern.** Pro Fund festhalten: ID/Schweregrad, historischer Codehash, Datei/Funktion/Zeile, auslösende Methode/Route/Request-Eigenschaften, Voraussetzungen, erwartetes und tatsächliches Verhalten, Auswirkung, Grenzen, Testkommando, Exitcode und Evidenzklasse. Niemals Tokens, echte Personen- oder Produktionsdaten archivieren.
3. **Root Cause korrigieren.** Zentralisiere Auth-Gates; prüfe, dass keine Spezialroute davor direkt antwortet. Verwende für öffentliche und interne Endpunkte getrennte geschlossene Verträge. Unbekannte Schlüssel nicht still verwerfen: ablehnen. Vertrauenswürdige Felder wie Status, Besitzer, Typ oder Tenant serverseitig setzen, nicht aus öffentlichem Request übernehmen.
4. **Parser fail-closed machen.** Definiere duplicate-key-, Tiefe-, Array-, Größen-, Unicode-/UTF-8- und Typverhalten. Regex nicht als JSON-Parser benutzen. Parser und öffentliche Fehlerbehandlung separat testen; Fehlerantworten dürfen keine Interna/Stacktraces preisgeben.
5. **Adversariale Regression hinzufügen.** Für jede bestätigte Lücke mindestens einen positiven und einen negativen Fall. Wiederhole den ursprünglichen Minimal-Request exakt gegen die Fixkopie; zusätzlich Mutationen für Aliasroute, HTTP-Methode, zusätzliche Felder, ungültige Typen/Werte, Grenzgrößen und verschachtelte Daten. Einen Test nur als `FIXED_REGRESSION_TESTED` kennzeichnen, wenn er gegen den korrigierten Quellhash tatsächlich lief.
6. **Restflächen markieren.** Rate-/Volumenangriffe, parallele Writes/Crash-Recovery, browserseitiges DOM/XSS, Rollen-/Tenant-Grenzen, Backup/Restore und externe Netz-/VPN-Prüfungen nur dann als PASS werten, wenn ausgeführt. Sonst `NOT_RUN`; fehlende Komponente `COMPONENT_NOT_FOUND`; beobachtetes, aber nicht ausnutzbar bestätigtes Verhalten `NOT_VERIFIED`.
7. **Wissen erhalten.** Fehler nicht aus der Liste löschen, wenn sie behoben sind. Status als `FIXED_REGRESSION_TESTED` fortschreiben; Root Cause, historische Reproduktion und Testreferenz erhalten. Aufgetauchte, ungeprüfte Varianten als priorisierte Mutationsliste ablegen.
8. **Neu paketieren.** Erneuere Versionsstand, Manifest/Hashes und ZIP erst nach Code, Tests und Bericht. Prüfe Originalarchiv unverändert, Quell-/ZIP-Mitglieder, Duplikate, Traversalpfade, Symlinks, ZIP-Integrität und ausgewiesene Ausschlüsse. Eine Prüfsumme ist keine Signatur/Provenance.

## Wiederverwendbare Prompt-Ergänzung

> Prüfe den konkreten historischen Quellhash und sichere eine read-only Zielkopie. Dokumentiere bei jedem Befund, wodurch er entdeckt wurde: exakter Route-/Methodenaufruf, Authstatus, synthetische Datenform, reproduziertes Ergebnis und passender Codepfad. Korrigiere bestätigte Root Causes in separater Kopie; füge für jede Korrektur ausführbare negative und positive Regressionstests hinzu und wiederhole exakt den ursprünglichen Angriff. Mutationssuche: Route-/Methodenmatrix, Auth-Bypass vor zentralen Gates, öffentliche zusätzliche Felder/Mass Assignment, Status-/Typ-/Owner-Übersteuerung, doppelte JSON-Schlüssel (auch verschachtelt), Prototyp-/Sonderkeys, Typ-/Enum-/Größen-/Tiefe-/Array-/Unicode-/UTF-8-Ränder, IDOR/Statusabfrage, DOM/XSS, Burst-/Timeout-/Recovery und Hashketten-Kürzung/Head-Rollback. Nur lokale synthetische und begrenzte Tests ohne externe Ziele; jede nicht ausgeführte Prüfung explizit `NOT_RUN`. Speichere einen dauerhaften Findings-Ledger mit historischem Hash, Entdeckungsmethode, Status, Fixcommit/-hash, Regressionstest, offenem Risiko und Folge-Mutationen. Lies Code/Testausgaben, erfinde keine E3-Reproduktion, ändere nicht die eingefrorene Auditkopie und vergebe kein pauschales Sicherheits- oder Produktions-GO.

## Referenzfall aus der Rathaus-OS-Remediation

Dieser Fall dient als Muster für Prüfreihenfolge, nicht als universelle Implementierungsbehauptung:

- **Route-Reihenfolge:** `GET /api/assets` stand vor einem zentralen Token-Gate; synthetischer unauthentifizierter Request ergab 200 und Inventardaten. Fix: vor authentifiziertes Gate verschoben; Regression prüft unauthentifiziert 401 und autorisiert 200.
- **Öffentliches DTO:** öffentlicher Bürger-Intake verwendete eine globale Feld-Allowlist, wodurch `owner` und `phone` in der internen Inbox gespeichert wurden. Fix: dedizierter Vertrag mit `category`/`description`, geschlossener Enum, festem Serverstatus und Ablehnung weiterer Keys.
- **Mehrdeutige JSON-Eingabe:** eingebautes `JSON.parse` akzeptierte doppelte Schlüssel mit „last value wins“. Fix: Duplicate-Key-Erkennung auch in verschachtelten Objekten plus Tiefe-/Arraygrenzen, generische 400-Antwort und HTTP-/Unit-Regressionen.

Die drei Root Causes lassen sich auf andere Frameworks übertragen: Route-Reihenfolge/Handler-Wiring, DTO-/Schema-Reuse über unterschiedliche Vertrauensstufen und parserseitige Mehrdeutigkeit.

## Minimaler Prüfmatrixvertrag

Jeder Security-Testeintrag enthält `test_id`, `mutation`, `setup`, `request_or_command`, `expected`, `actual`, `status`, `source_hash`, `evidence_class`, `cleanup` und `related_finding`. Ausgabe zählt echte Testläufe; Quelltextbetrachtung zählt nicht als ausführbarer Test. Der Release-Status bleibt `RED_TEAM_FAILED`, solange eine bestätigte Lücke offen ist; behobene Ergebnisse werden als begrenzter Scope berichtet und nicht zu einer Gesamtzertifizierung hochgestuft.
