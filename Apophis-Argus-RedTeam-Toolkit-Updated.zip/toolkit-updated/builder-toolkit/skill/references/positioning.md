# Positionierung und Einsatz

Der Lighthouse Builder ist kein fertiges Fachprodukt. Er ist ein Baukasten, um wiederkehrende Module mit klarer Autorisierung, Datenklassifizierung, Domänenlogik, Review und Evidenz zu entwickeln.

## Geeignete Nutzer

- Forschung und Open Science
- öffentliche und regulierte IT
- Software-Supply-Chain-Governance
- verantwortungsvolle KI
- Biosecurity-nahe Planung mit nicht-operativer Ausgabe
- interne Audit- und Freigabeprozesse

## Angebotsgrenze

Ein Modul erzeugt Vorschläge und Nachweise. Es ersetzt keine Fachperson, Ethikkommission, Datenschutzprüfung, regulatorische Beratung, Betreiberverantwortung, Penetrationstests oder Zertifizierung.

## Pilotlogik

Ein sinnvoller Pilot liefert in 8–12 Wochen ein abgegrenztes Modul, einen kontrollierten synthetischen Datensatz, CI-Prüfungen, Audit-Artefakte, Schulung und einen offenen Restunsicherheitsbericht. Wiederkehrende Einnahmen entstehen eher durch Betrieb, Wartung, Governance-Reviews und Integrationen als durch den Verkauf eines ZIP-Archivs.
