# Test- und Read-only-Audit-Protokoll

## Testgruppen

1. Schema: gültig, fehlend, unbekanntes Enum, Größenlimit.
2. Authorization: gültig, fehlt, manipuliert, falsche Rolle.
3. Data routing: erlaubte und verbotene Klassen/Routen.
4. Tenant/object scope: eigener Datensatz, fremder Datensatz, Traversal, direkte ID.
5. Safety: jedes forbidden intent, Verschleierung, Prompt Injection, Tool-Missbrauch.
6. Review: kritischer Befund blockiert; Warnung bleibt sichtbar.
7. Output: Pflichtfelder, Status, Disclaimer, keine gefährliche Teilnutzlast.
8. Reproducibility: gleiche Eingabe/Policy ergibt nachvollziehbare Ausgabe und Hashes.

## Auditregeln

- Zielartefakte im Audit nicht ändern.
- Auditbericht und Hashsnapshot in ein separates Ziel oder erst nach dem Read-only-Lauf schreiben.
- Inventar, Git-Status, Toolversionen und Environment separat sichern.
- Jede Behauptung mit exakter Quelle oder ausführbarer Probe verknüpfen.
- `PASS` nur nach ausgeführter Probe.
- `FAILED` bei fehlender Implementierung oder verletzter Eigenschaft.
- `BLOCKED` nur bei ausdrücklich dokumentiertem externem Hindernis.
- `PASS_WITH_LIMITATIONS` verwenden, wenn die lokalen Proben bestanden wurden, aber unabhängige oder externe Evidenz fehlt.
- Statische Suche, Dokumentation oder Dependency-Deklaration allein sind kein Laufzeitbeweis.

Der Inventarhash muss seinen Scope nennen. Empfohlen ist `source-and-test-inputs-only`; generierte Reports, Provenance und Auditoutputs werden nicht in ihren eigenen Hash aufgenommen.

## Finding-Format

```json
{
  "finding_id": "F-001",
  "severity": "high",
  "status": "open",
  "evidence_status": "observed",
  "property": "cross-tenant access is denied",
  "observation": "foreign object returned",
  "consequence": "confidentiality boundary failure",
  "reproduction": "command or test id",
  "remediation": "specific corrective action",
  "residual_uncertainty": "..."
}
```
