# Security- und Vollständigkeitsprüfung des Leuchtturm-Werkzeugkastens

**Prüfart:** statische Sichtung der Skripte, Dokumentation und Spezifikation plus lokale synthetische Tests. **Keine externe Normverifikation, keine Penetration, keine Produktionsprüfung.** Findings sind Code-/Dokumentationsbeobachtungen, keine Aussage über Ausnutzbarkeit in jeder Deployment-Umgebung.

## Ergebnis in Kürze

- Mit dem Toolkit kann ich Module entwerfen, Scaffolds generieren, synthetische Policy-/Plattformtests ausführen, Kataloge/Hashmanifeste/unsignierte Provenance-Metadaten erstellen und einen dokumentierten Review-Prozess aufsetzen.
- Es ist **kein vollständig gehärtetes Assurance- oder Security-Testsystem**. Ein erfolgreicher Lauf bedeutet nur, dass die konkret ausgeführten Prüfungen in der lokalen Umgebung bestanden haben.
- Gesamtbewertung: `PASS_WITH_LIMITATIONS`. Es gibt bekannte Hochrisiko-Hardening-Lücken in einzelnen Helferskripten; bis zur Behebung nur mit geprüftem Code in temporärer, unprivilegierter und netzwerkisolierter Umgebung arbeiten.

## Wichtige Findings

| Priorität | Komponente | Finding | Sichere Verwendung / nächste Maßnahme |
|---|---|---|---|
| Kritisch | `scripts/run_assurance.py` | Führt Tests und `policy/evaluate.py` aus dem Zielmodul als Python-Code mit Rechten des aktuellen Benutzers aus. Das ist keine Sandbox. | Nur vorher geprüften Code in disposable, unprivilegierter, netzwerkisolierter Umgebung ausführen; mittelfristig Sandbox-Executor mit CPU-/Speicher-/Zeitlimits und Prozessgruppen-Abbruch ergänzen. |
| Hoch | Assurance Runner | Kein robustes Timeout/Ressourcenlimit; Subprozessausgaben werden zunächst komplett gepuffert und nur danach gekürzt. Reports können kontrollierte Inhalte/Geheimnisse übernehmen. | Keine sensiblen Fixtures; Ausgabe minimieren/redigieren; externen Ressourcenbegrenzer nutzen; Runner-Redesign nötig. |
| Hoch | `scripts/build_manifest.py` | Rekursives Traversieren folgt potenziell Symlinks; Ausgabeziel ist frei wählbar und kann bestehende Dateien überschreiben. | Symlinks ablehnen/Scope auflösen; Ausgaben nur in neues dediziertes Verzeichnis schreiben; vor Überschreiben prüfen. |
| Hoch | `scripts/build_catalog.py` | Manifestwerte werden ungeescaped in Markdown-Tabellen interpoliert; manipulierte Felder können Report-Struktur/HTML beeinflussen. | Keine untrusted Manifeste; bis Fix Output escapen und Feldtypen/Längen validieren. |
| Mittel | `scripts/validate_catalog.py` | Symlink-Pfade können Scope verlassen; falsche JSON-Typen können Validator-Ausnahme statt sauberem Fehler auslösen. | Nur geprüfte Manifeste; Schema-/Typvalidierung ergänzen und kanonische Ziele innerhalb des Roots erzwingen. |
| Mittel | `scripts/init_module.py` | Zielsymlink wird durch `resolve()` verfolgt; Teilverzeichnisse können bei Fehlern zurückbleiben. | Nur frisches, kontrolliertes Zielverzeichnis verwenden; atomare Erstellung und Symlink-Verweigerung ergänzen. |
| Mittel | `scripts/build_provenance.py` / Report-Generatoren | CI-Metadaten werden als Werte übernommen; frei wählbare Outputpfade können bestehende Dateien überschreiben. Provenance bleibt ausdrücklich unsigniert. | Werte validieren, Herkunft markieren, neues Outputziel nutzen; niemals als Attestation interpretieren. |
| Mittel | Hashumfang / Doku | Assurance-Inventar hasht nur vorhandene Dateien aus einer statischen Pflichtliste; es ist kein vollständiger Quell-/Test-Snapshot. | Umfang im Report präzisieren; später rekursiven, symlink-sicheren Scope mit Ausschlussliste implementieren. |
| Mittel | v2-Entwurf | Profil-Gate-Listen sind nicht durchgehend vollständig zur globalen Sequenz; Registry-Einträge sind nicht mit Primärquellen-Reviewdaten pro Item belegt. Dokument-ID `LH-GLOBAL-2026-11-03` liegt nach dem Paketstand 21.10.2026. | Profile als Ergänzungen zur globalen Pflichtbaseline behandeln; jede Norm einzeln mit Primärquelle, Stand, Jurisdiktion, Owner und Reviewdatum validieren; Zukunftsdatum klären. |
| Mittel | Roadmap/Beispielvertrag | „tested“-Ziele in geplanten Phasen und beispielhafte `true`-Werte können als bereits belegt missverstanden werden. | Nur als Ziel-Evidenz markieren; Beispielbooleans nur aus konkreter protokollierter Prüfung erzeugen. |
| Mittel | Dashboard | Inline JS-Syntax ist prüfbar; Layout/CDN-Abhängigkeiten und Browserverhalten sind ohne Browser-Render nicht verifiziert. Externe Font-CDNs bedeuten nicht offline autark. | Für Offline-Betrieb Assets lokal bundeln; UI separat browser-testen. |

## Fehlende Fähigkeiten für einen echten Produktions-Assurance-Stack

Nicht enthalten oder nicht nachgewiesen: isolierter Codeexecutor; standardisierte CPU-/Speicher-/Prozess-/Datei-/Netzwerk-Sandbox; vollständige SAST/Secret/Dependency-Scanner; Fuzz-/Property-/Mutation-Testharness; echte Schema-Enforcement-Layer für alle Ausgaben; signierte und verifizierbare Attestation; Identitätsprovider- und Tenant-Isolation-Integration; Schutz vor Symlink-/TOCTOU-/Output-Overwrite; primärquellengeprüfter Standards-Crosswalk; unabhängige Reviewdaten und kontrollierter externer Evidence Store. Die v2-Datei beschreibt Teile davon als Ziele/Gaps, aber implementiert sie nicht durch ihre bloße Existenz.

## Lokale Prüfungen

Aktueller Lauf ist im Paket `TEST-REPORT.md` dokumentiert. Umfasste Prüfungen: Python-Syntax; Validator; synthetisches Plattformlabor mit 8 Modulen und 28 Fällen; drei Katalogbeispiele; frisches Scaffold samt Assurance-Lauf; Generator-Smoke-Tests; Inline-JavaScript-Syntax; Markdown-/JSON-Synchronität und SHA-256/Bytezahl. Assurance-Urteil `PASS_WITH_LIMITATIONS`, weil drei Prüffamilien nicht ausgeführt wurden.

## Explizit nicht durchgeführt

- kein unabhängiges Security-/Domain-/Red-Team-Review;
- keine externe Identitäts-, Signatur- oder CI-Attestation-Verifikation;
- kein Penetrations-, Feld-, Labor- oder Produktionstest;
- keine Prüfung der 70 Norm-/Regulierungsreferenzen gegen Primärquellen;
- keine Zertifizierung, Akkreditierung oder Rechtsbewertung.
