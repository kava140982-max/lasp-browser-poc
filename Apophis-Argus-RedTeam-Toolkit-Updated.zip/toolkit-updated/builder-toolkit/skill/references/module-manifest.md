# Module Manifest und Normmapping

## Ziel

Das Manifest ist die Single Source of Truth für Identität, Scope, Rollen, Datenklassen, Aufgaben, Policies und Beweisstatus eines Moduls.

## Pflichtstruktur

```yaml
schema: apophis/module-manifest/v1
module_id: example-domain-planner
module_version: 1.0.0
domain: example-domain
author: organization-or-owner
status: draft
prime_directive: no-authorization-no-execution
scope:
  target_level: advisory
  allowed_tasks: [evaluate, plan, summarize]
  forbidden_tasks: [execute, approve, publish]
security_profile: general-high-assurance
roles:
  allowed: [domain_reviewer]
  independent_review_required: true
data:
  accepted_classes: [public_research, internal_research]
  denied_classes: [clinical_pii, classified]
routes:
  local: allowed
  api: conditional
  external_write: denied
rules: []
review_adapters: []
required_artifacts: []
not_a_certification: true
```

## Normmapping

Für jede normative Forderung dokumentiere:

```json
{
  "requirement_id": "MC-01",
  "source": "normative-reference.txt#section",
  "requirement": "authorization is independently verified",
  "implementation": ["security-envelope.authorization"],
  "test": ["tests/authorization.test.js"],
  "evidence": "artifacts/traceability-matrix.json#MC-01",
  "status": "tested",
  "residual_uncertainty": "identity provider not connected in local demo"
}
```

Verwende nur `implemented`, `tested`, `observed`, `unverified`, `failed` oder `not_applicable`. Verwende `compliant` nur nach einer ausdrücklich autorisierten, konkreten Konformitätsprüfung.
