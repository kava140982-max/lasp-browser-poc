# Domänenprofile

Lade genau ein Profil pro Modul. Profile sind Leitplanken, keine Rechtsberatung.

## General High Assurance

Verwende für Governance-, Evidence-, Supply-Chain- und Verwaltungssoftware. Fordere unabhängige Freigabe für externe Wirkung, Signierung, Löschung und Veröffentlichung.

## Life Sciences / Biosecurity

Verwende für biologische, medizinische oder klinische Domänen. Erlaube nur nicht-operative, hochrangige Planung und Evidenzbewertung. Blockiere Kultivierung, Vermehrung, Modifikation, Gain-of-Function, Pathogenitätssteigerung, klinische Dosierung und patientenspezifische Therapieanweisung. Kennzeichne Annahmen, BSL-Einstufung, KI-Hypothesen und Human Review.

## KRITIS / Public Infrastructure

Verwende für kritische oder öffentliche Infrastruktur. Fordere Asset-Scope, Betreiberverantwortung, Incident Response, Backup/Restore, Change Control, Lieferkettennachweis und unabhängige Prüfung. Behaupte keine KRITIS- oder NIS2-Konformität aus lokalen Tests.

## Privacy / Regulated Data

Verwende für personenbezogene, Gesundheits- oder besonders geschützte Daten. Fordere Zweckbindung, Datenminimierung, Zugriffskontrolle, Aufbewahrung, Export-/Löschkonzept und Datenschutz-Folgenabschätzung durch verantwortliche Stellen. Route nicht freigegebene Daten nicht an externe Modelle.

## Risk classification

- `R0`: rein informativ, keine externe Wirkung.
- `R1`: interner Entwurf mit menschlicher Prüfung.
- `R2`: institutioneller Vorschlag mit Zweck-/Rollenbindung.
- `R3`: hochwirksamer oder regulierter Vorschlag; unabhängige Fachprüfung obligatorisch.
- `R4`: operative, sicherheitskritische oder irreversible Wirkung; Modul darf nur vorbereiten und muss Ausführung verweigern.
