#!/usr/bin/env python3
"""Fail-closed validator for an Apophis Lighthouse module scaffold."""
import json
import sys
from pathlib import Path

REQUIRED = [
    "SKILL.md",
    "references/module-manifest.md",
    "references/security-gates.md",
    "references/domain-profiles.md",
    "references/contracts.md",
    "references/audit-protocol.md",
    "templates/module.yaml",
    "templates/output.json",
    "templates/traceability-matrix.json",
]

def main():
    root = Path(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).resolve().parents[1])
    failures = []
    for rel in REQUIRED:
        if not (root / rel).is_file():
            failures.append(f"missing:{rel}")
    skill = root / "SKILL.md"
    if skill.exists():
        text = skill.read_text(encoding="utf-8")
        if len(text.splitlines()) >= 500:
            failures.append("SKILL.md exceeds 500 lines")
        if not text.startswith("---\nname:"):
            failures.append("SKILL.md frontmatter missing")
        for marker in ("fail closed", "requires_human_review", "not a certification", "read-only-audit"):
            if marker.lower() not in text.lower():
                failures.append(f"SKILL.md missing concept:{marker}")
    for rel in ("templates/output.json", "templates/traceability-matrix.json"):
        path = root / rel
        if path.exists():
            try:
                json.loads(path.read_text(encoding="utf-8"))
            except json.JSONDecodeError as exc:
                failures.append(f"invalid-json:{rel}:{exc}")
    result = {"verdict": "FAILED" if failures else "PASS", "root": str(root), "required_files": len(REQUIRED), "failures": failures}
    print(json.dumps(result, indent=2))
    return 1 if failures else 0

if __name__ == "__main__":
    raise SystemExit(main())
