#!/usr/bin/env python3
"""Validate Lighthouse-compatible module manifests with explicit path scope."""
import argparse
import json
import re
from pathlib import Path

ID_RE = re.compile(r"^[a-z][a-z0-9-]{2,40}$")
LEVELS = {"present", "internally_tested", "externally_confirmed"}
KINDS = {"core", "helper", "separate"}
NETWORKS = {"none", "loopback_only", "api_conditional"}
ACCESS = {"self", "none", "read", "propose"}
FORBIDDEN = re.compile(r"(zertifiziert|certified|garantiert|unhackbar|100\s?%)", re.I)

def safe_in_scope(root, rel):
    parts = Path(rel).parts
    candidate = root.joinpath(*parts)
    cursor = root
    for part in parts:
        cursor = cursor / part
        if cursor.is_symlink():
            return False
    resolved = candidate.resolve()
    return resolved.is_relative_to(root.resolve()) and resolved.exists()

def validate(manifest_dir, root):
    errors = []
    manifests = sorted(manifest_dir.glob("*.json"))
    ids = set()
    if not manifests:
        errors.append("no_manifests")
    for file in manifests:
        try:
            m = json.loads(file.read_text(encoding="utf-8"))
        except Exception as exc:
            errors.append(f"{file.name}:invalid_json:{exc}")
            continue
        def err(msg): errors.append(f"{file.name}:{msg}")
        for field in ("id", "name", "summary", "kind", "maintainer", "network", "core_access"):
            if not isinstance(m.get(field), str) or not m[field].strip(): err(f"missing:{field}")
        mid = m.get("id", "")
        if not ID_RE.fullmatch(mid): err("invalid_id")
        if mid in ids: err("duplicate_id")
        ids.add(mid)
        if file.name != f"{mid}.json": err("filename_must_match_id")
        if m.get("kind") not in KINDS: err("invalid_kind")
        if m.get("network") not in NETWORKS: err("invalid_network")
        if m.get("core_access") not in ACCESS: err("invalid_core_access")
        if m.get("kind") == "core" and m.get("core_access") != "self": err("core_requires_self_access")
        if m.get("kind") != "core" and m.get("core_access") == "self": err("non_core_cannot_self_access")
        if FORBIDDEN.search(m.get("summary", "")): err("unsupported_claim_in_summary")
        limits = m.get("limits")
        if not isinstance(limits, list) or not limits: err("limits_required")
        maturity = m.get("maturity") or {}
        level = maturity.get("level")
        if level not in LEVELS: err("invalid_maturity")
        paths = m.get("paths") or []
        if not paths and not m.get("external_location"): err("paths_or_external_location_required")
        for rel in paths:
            if not isinstance(rel, str) or rel.startswith("/") or ".." in Path(rel).parts: err(f"unsafe_path:{rel}")
            elif not safe_in_scope(root, rel): err(f"unsafe_or_missing_path:{rel}")
        if level == "internally_tested":
            evidence = maturity.get("evidence") or []
            if not evidence: err("internal_evidence_required")
            for rel in evidence:
                if not safe_in_scope(root, rel): err(f"unsafe_or_missing_evidence:{rel}")
        if level == "externally_confirmed" and not maturity.get("external_report"): err("external_report_required")
    return errors

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest_dir", type=Path)
    parser.add_argument("--root", type=Path, default=None)
    args = parser.parse_args()
    root = (args.root or args.manifest_dir.parent).resolve()
    errors = validate(args.manifest_dir.resolve(), root)
    print(json.dumps({"verdict": "FAILED" if errors else "PASS", "manifests": len(list(args.manifest_dir.glob('*.json'))), "root": str(root), "errors": errors, "not_a_certification": True}, indent=2))
    return 1 if errors else 0

if __name__ == "__main__": raise SystemExit(main())
