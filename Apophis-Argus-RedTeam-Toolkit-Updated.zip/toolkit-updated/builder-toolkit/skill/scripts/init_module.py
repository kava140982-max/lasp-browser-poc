#!/usr/bin/env python3
"""Scaffold a domain module without overwriting an existing directory."""
import argparse
import json
import re
import shutil
from pathlib import Path

ID_RE = re.compile(r"^[a-z][a-z0-9-]{2,63}$")

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("module_id")
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    if not ID_RE.fullmatch(args.module_id):
        raise SystemExit("invalid module_id: use lowercase kebab-case")
    target_input = args.destination
    if target_input.is_symlink():
        raise SystemExit("refusing symlink destination")
    cursor = target_input.parent
    while cursor != cursor.parent:
        if cursor.is_symlink():
            raise SystemExit(f"refusing symlink path component: {cursor}")
        cursor = cursor.parent
    target = target_input.resolve()
    if target.exists() and any(target.iterdir()):
        raise SystemExit(f"refusing to overwrite non-empty directory: {target}")
    target.mkdir(parents=True, exist_ok=True)
    for directory in ("schemas", "tests", "artifacts", "references", "policy", "catalog"):
        (target / directory).mkdir()
    root = Path(__file__).resolve().parents[1]
    module = (root / "templates" / "module.yaml").read_text(encoding="utf-8").replace("replace-me", args.module_id, 1)
    (target / "module.yaml").write_text(module, encoding="utf-8")
    output = json.loads((root / "templates" / "output.json").read_text(encoding="utf-8"))
    output["module_id"] = args.module_id
    (target / "schemas" / "output.example.json").write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    cases = (root / "templates" / "test-cases.json").read_text(encoding="utf-8")
    (target / "tests" / "test-cases.json").write_text(cases, encoding="utf-8")
    (target / "artifacts" / "traceability-matrix.json").write_text(json.dumps({"schema": "apophis/traceability-matrix/v1", "module_id": args.module_id, "entries": []}, indent=2) + "\n", encoding="utf-8")
    (target / "artifacts" / "policy-evaluation.json").write_text(json.dumps({"schema": "apophis/policy-evaluation/v1", "module_id": args.module_id, "status": "unverified", "findings": []}, indent=2) + "\n", encoding="utf-8")
    (target / "artifacts" / "test-report.json").write_text(json.dumps({"schema": "apophis/test-report/v1", "module_id": args.module_id, "status": "not_run", "tests": []}, indent=2) + "\n", encoding="utf-8")
    (target / "schemas" / "input.schema.json").write_text(json.dumps({"$schema": "https://json-schema.org/draft/2020-12/schema", "type": "object", "additionalProperties": False, "required": ["schema", "message_id", "authorization_id", "task", "data_class", "model_route", "context_payload"]}, indent=2) + "\n", encoding="utf-8")
    (target / "schemas" / "output.schema.json").write_text(json.dumps({"$schema": "https://json-schema.org/draft/2020-12/schema", "type": "object", "additionalProperties": False, "required": ["schema", "message_id", "module_id", "module_version", "status", "requires_human_review", "deliverables", "traceability_id"]}, indent=2) + "\n", encoding="utf-8")
    (target / "tests" / "fixtures.json").write_text(json.dumps([{"schema": "apophis/module-request/v1", "message_id": "example-1", "authorization_id": "auth-example", "task": "evaluate", "data_class": "public_research", "model_route": "local", "context_payload": {}}], indent=2) + "\n", encoding="utf-8")
    (target / "policy" / "evaluate.py").write_text("""#!/usr/bin/env python3\nimport hashlib, json, sys\nMODULE = %r\ndef evaluate(req):\n    required = ['schema','message_id','authorization_id','task','data_class','model_route','context_payload']\n    tid = hashlib.sha256(json.dumps(req, sort_keys=True).encode()).hexdigest()[:16]\n    base = {'schema':'apophis/module-suggestion/v1','message_id':req.get('message_id'),'module_id':MODULE,'module_version':'0.1.0','requires_human_review':True,'deliverables':{},'traceability_id':tid}\n    if any(k not in req for k in required): base.update(status='invalid_request'); return base\n    if not req.get('authorization_id'): base.update(status='denied'); return base\n    base.update(status='pending_review'); base['deliverables']={'candidate_only':True}; return base\nif __name__ == '__main__': print(json.dumps([evaluate(x) for x in json.load(open(sys.argv[1]))], indent=2))\n""" % args.module_id, encoding="utf-8")
    (target / "tests" / "test_policy.py").write_text("""import json, subprocess, sys, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
class ScaffoldPolicyTest(unittest.TestCase):
    def test_fixture_returns_reviewable_suggestion(self):
        out = subprocess.check_output([sys.executable, str(ROOT/'policy/evaluate.py'), str(ROOT/'tests/fixtures.json')])
        result = json.loads(out)[0]
        self.assertEqual(result['status'], 'pending_review')
        self.assertTrue(result['requires_human_review'])
        self.assertEqual(result['schema'], 'apophis/module-suggestion/v1')
if __name__ == '__main__': unittest.main()
""", encoding="utf-8")
    (target / "catalog" / f"{args.module_id}.json").write_text(json.dumps({"id": args.module_id, "name": args.module_id, "summary": "Advisory-only module; not a certification.", "kind": "helper", "maintainer": "replace-me", "network": "none", "core_access": "none", "paths": ["module.yaml", "schemas/", "policy/", "tests/", "artifacts/"], "limits": ["Not a certification.", "Human review is mandatory."], "maturity": {"level": "present", "evidence": [], "external_report": None}}, indent=2) + "\n", encoding="utf-8")
    (target / "README.md").write_text(f"# {args.module_id}\n\nStatus: draft. This module is advisory and not a certification.\n\nHuman review is required before consequential use.\n", encoding="utf-8")
    (target / "SECURITY.md").write_text(f"# Security boundary: {args.module_id}\n\nFail closed on missing authorization, invalid schema, forbidden intent, unroutable data, tenant mismatch, or critical review findings.\n\nThis scaffold is not a certification.\n", encoding="utf-8")
    print(json.dumps({"verdict": "PASS", "module_id": args.module_id, "path": str(target), "overwrote_existing": False}, indent=2))

if __name__ == "__main__":
    main()
