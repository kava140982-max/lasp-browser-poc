#!/usr/bin/env python3
"""Create a deterministic SHA-256 manifest for normative/module artifacts."""
import hashlib
import json
import os
import sys
import stat
from pathlib import Path
from datetime import datetime, timezone

def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()

def safe_file(path, root):
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"refusing non-regular or symlink input: {path}")
    resolved = path.resolve()
    if not resolved.is_relative_to(root.resolve()):
        raise ValueError(f"input escapes root: {path}")
    return resolved

def main():
    root = Path(sys.argv[1] if len(sys.argv) > 1 else Path.cwd()).resolve()
    output = Path(sys.argv[2] if len(sys.argv) > 2 else root / "artifacts" / "lighthouse-manifest.json").resolve()
    if not root.is_dir(): raise SystemExit(f"root is not a directory: {root}")
    if not output.is_relative_to(root): raise SystemExit("output must remain inside root")
    if output.exists() or output.is_symlink(): raise SystemExit(f"refusing to overwrite existing output: {output}")
    files = []
    for path in sorted(root.rglob("*")):
        if path == output or ".git" in path.parts or "__pycache__" in path.parts:
            continue
        try:
            safe = safe_file(path, root)
        except ValueError as exc:
            raise SystemExit(str(exc))
        files.append({"path": str(safe.relative_to(root)), "bytes": safe.stat().st_size, "sha256": sha256(safe)})
    manifest = {
        "schema": "apophis/lighthouse-manifest/v1",
        "root": str(root),
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "files": files,
        "not_a_certification": True,
        "scope": "module-scaffold-integrity",
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"verdict": "PASS", "manifest": str(output), "files": len(files)}, indent=2))

if __name__ == "__main__":
    main()
