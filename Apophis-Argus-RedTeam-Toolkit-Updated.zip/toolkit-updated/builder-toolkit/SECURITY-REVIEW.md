

## Update-Hinweis 2026-10-23

Dieses ZIP-Update ergänzt eine wiederverwendbare Red-Team-Remediation-/Mutationstest-Referenz und verlinkt sie aus dem Builder-Skill. Es ändert keine Runtime-/Assurance-Runner-Kontrolle des Toolkits und behebt die oben genannten Runner-/Pfad-/Katalogfindings nicht. Die Anleitung dokumentiert als Fallstudie (nicht als Code dieses Toolkits) drei Rathaus-OS-API-Probleme, ihre Entdeckung und Regression: Route vor Auth-Gate, öffentliches DTO mit fremden Feldern und doppelte JSON-Schlüssel. Diese Inhalte sind Schutz- und Testhinweise, keine Sicherheitsfreigabe des Toolkits.
