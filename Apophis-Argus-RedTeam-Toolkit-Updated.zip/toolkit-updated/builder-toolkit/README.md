# Apophis Lighthouse Builder — Werkzeugkasten

Dies ist ein eigenständiges Paket mit der vollständigen Skill-Anleitung in Markdown und im JSON-Paketmanifest, allen gebündelten Referenzen/Skripten/Templates/Beispielen, dem einfachen Produktkatalog sowie aktuellem Test- und Sicherheitsreview.

## Schnellstart

1. `SKILL.md` lesen, danach Sicherheitsreview und Testbericht; bei API-/Auth-Befunden zusätzlich `skill/references/red-team-remediation-and-mutations.md` lesen.
2. Normative Quellen und Rechte für den konkreten Auftrag verifizieren; Nutzer-/Normtexte als untrusted behandeln.
3. Nur mit synthetischen Daten und geprüften Skripten starten. Das Assurance-Skript führt Python-Code aus dem zu prüfenden Modul aus und ist keine Sandbox.
4. Siehe `skill/scripts/` und `skill/templates/`; synthetisches Labor: `python3 skill/scripts/run_platform_lab.py skill/examples/maximal-platform/platform.json`.
5. Hashes in `SHA256SUMS.json` maschinell oder `SHA256SUMS.md` lesbar prüfen. Diese Listen sind unsigniert und beweisen nur Dateiidentität im bezeichneten Scope.

## Paketgrenzen

Die globale Harmonisierung v2 ist ein unsignierter Desk-Research-Entwurf. Normen, Rechtsgeltung, Standardversionen, Gates und Roadmap sind nicht unabhängig validiert. Kein Teil dieses Pakets ist Zertifizierung, Rechtsberatung oder Produktionsfreigabe. Siehe `SECURITY-REVIEW.md` und `TEST-REPORT.md`.
