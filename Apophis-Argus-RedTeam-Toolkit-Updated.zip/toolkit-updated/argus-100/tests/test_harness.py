import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "policy"))
from evaluate import MODULE_RISK, evaluate  # noqa: E402

FIXTURES = json.loads((ROOT / "tests/fixtures.json").read_text(encoding="utf-8"))

class Babel9HarnessTests(unittest.TestCase):
    def test_every_deterministic_case_matches_expected_gate_and_status(self):
        failures = []
        observed = []
        output_schema = json.loads((ROOT / "schemas/output.schema.json").read_text(encoding="utf-8"))
        required_output = set(output_schema["required"])
        allowed_statuses = set(output_schema["properties"]["status"]["enum"])
        for req in FIXTURES:
            actual = evaluate(req)
            observed.append(actual)
            if not required_output.issubset(actual) or actual["status"] not in allowed_statuses:
                failures.append({"case_id": req["case_id"], "problem": "output_schema_contract"})
            if actual["status"] != req["expected_status"] or actual["gate"] != req["expected_gate"]:
                failures.append({"case_id": req["case_id"], "expected": [req["expected_status"], req["expected_gate"]], "actual": [actual["status"], actual["gate"]]})
            if actual["status"] in {"denied", "blocked", "invalid_request"} and actual["deliverables"] != {}:
                failures.append({"case_id": req["case_id"], "problem": "unsafe_partial_deliverable"})
            if actual.get("not_a_certification") is not True:
                failures.append({"case_id": req["case_id"], "problem": "missing_not_a_certification"})
        self.assertEqual(failures, [], json.dumps(failures, ensure_ascii=False))
        self.assertEqual(len(MODULE_RISK), 9)
        self.assertEqual(set(MODULE_RISK.values()), {"R0", "R1", "R2", "R3", "R4"})
        self.assertTrue(all(x["not_a_certification"] is True for x in observed))

    def test_r4_claim_is_blocked_even_when_request_supplies_tested_word(self):
        req = next(x for x in FIXTURES if x["case_id"] == "bio-advisory-r4-no-evidence")
        claimed = dict(req, risk_evidence_status="tested")
        result = evaluate(claimed)
        self.assertEqual((result["status"], result["gate"]), ("blocked", "EVID-01"))
        self.assertIn("RISK_DECLARATION_UNSUPPORTED", result["flags"])
        self.assertTrue(result["finding"])

    def test_multilingual_injection_cases_have_inject_flag(self):
        by_id = {x["case_id"]: x for x in FIXTURES}
        for lang in ("cn", "en", "ru", "de", "ar"):
            case_id = f"injection-{lang}"
            result = evaluate(by_id[case_id])
            self.assertEqual(result["status"], "denied", case_id)
            self.assertIn("INJECT-01", result["flags"], case_id)

    def test_structural_missing_auth_precedes_auth_gate_but_empty_auth_is_denied(self):
        by_id = {x["case_id"]: x for x in FIXTURES}
        missing = evaluate(by_id["bio-advisory-auth-missing"])
        empty = evaluate(by_id["bio-advisory-auth-empty"])
        mixed = evaluate(by_id["ordering-invalid-schema-auth-mix"])
        valid_but_unauthorized = evaluate(by_id["ordering-valid-schema-missing-auth"])
        self.assertEqual((missing["status"], missing["gate"]), ("invalid_request", "SCHEMA-01"))
        self.assertEqual((empty["status"], empty["gate"]), ("denied", "AUTH-01"))
        self.assertEqual((mixed["status"], mixed["gate"]), ("invalid_request", "SCHEMA-01"))
        self.assertEqual((valid_but_unauthorized["status"], valid_but_unauthorized["gate"]), ("denied", "AUTH-01"))

if __name__ == "__main__":
    unittest.main()
