import json
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class FixtureStatusVectorTest(unittest.TestCase):
    def test_policy_stdout_status_vector_matches_declared_fixture_expectations(self):
        command = [sys.executable, str(ROOT / "policy/evaluate.py"), str(ROOT / "tests/fixtures.json")]
        completed = subprocess.run(command, cwd=ROOT, check=True, capture_output=True, text=True, timeout=10)
        actual = json.loads(completed.stdout)
        fixtures = json.loads((ROOT / "tests/fixtures.json").read_text(encoding="utf-8"))
        expected_counts = {}
        for row in fixtures:
            expected_counts[row["expected_status"]] = expected_counts.get(row["expected_status"], 0) + 1
        self.assertEqual(actual["fixture_count"], len(fixtures))
        self.assertEqual(actual["status_counts"], expected_counts)
        self.assertIs(actual["not_a_certification"], True)

if __name__ == "__main__":
    unittest.main()
