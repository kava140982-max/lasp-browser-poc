# Argus-100 Sandbox Harness

> Reiner lokaler Testkörper mit synthetischen Strings und Daten. Kein Zielsystem, keine Steuerung, kein Deployment, keine klinische Beratung. **Keine Zertifizierung.**

Dieses Harness erweitert den vorherigen Babel-9-Werkzeugkasten um eine absichtlich feindselige 9-Modul-Testmatrix. Enthalten sind 9 Domänen und die Härtegrade R0–R4. Die 504 deterministischen Fixtures umfassen 225 domänenspezifische Fälle, Envelope-Fälle je Modul, 20 Cross-Module-Varianten, fünf Injektionssprachen (CN/EN/RU/DE/AR), Replay-/Zeit-/Self-Attestation- und Reihenfolgeprüfungen. Alle Angriffsformulierungen sind nur Testdaten, nie operative Anweisungen.

## Lokal ausführen

```bash
cd /home/ubuntu/work/argus-100-sandbox-harness
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v
PYTHONDONTWRITEBYTECODE=1 python3 scripts/run_platform_lab.py examples/maximal-platform/platform.json
PYTHONDONTWRITEBYTECODE=1 python3 scripts/run_assurance.py . --output artifacts/runner-raw-results.json
PYTHONDONTWRITEBYTECODE=1 python3 scripts/build_artifacts.py
```

`run_assurance.py` startet Projektcode und ist keine Sandbox. Diese Ausführung nutzte synthetische Tests. Die Umgebung gestattete keine Kernel-Netzwerkisolation via `unshare -n`; daher wird nur festgehalten, dass im geprüften Testcode keine Netzaufrufe vorhanden waren, nicht dass OS-seitige Isolation garantiert war. Keine echten Daten, IdPs, externen Reviewer oder Produktionssysteme verwenden.

Das Endergebnis schreibt `artifacts/all-test-results.json`, `artifacts/traceability-matrix.json` und `artifacts/domain-coverage.json`. `tested` bezieht sich allein auf konkrete lokale Fälle. Unverified/externe Prüfungen bleiben `NOT_EXECUTED`; kein `proven`/`compliant`.
