#!/usr/bin/env python3
"""Run deterministic module assurance checks with fail-closed isolation requirements."""
import argparse, hashlib, json, os, resource, shutil, signal, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path

DECISIONS = {"PASS", "FAILED", "BLOCKED", "NOT_EXECUTED", "PASS_WITH_LIMITATIONS"}

MAX_SECONDS = 20
MAX_OUTPUT = 4000
MAX_MEMORY = 768 * 1024 * 1024

def _limits():
    resource.setrlimit(resource.RLIMIT_CPU, (MAX_SECONDS, MAX_SECONDS))
    resource.setrlimit(resource.RLIMIT_AS, (MAX_MEMORY, MAX_MEMORY))
    resource.setrlimit(resource.RLIMIT_FSIZE, (10 * 1024 * 1024, 10 * 1024 * 1024))

def run(cmd, cwd, allow_execution):
    base = {"command": " ".join(map(str, cmd)), "limits": {"cpu_seconds": MAX_SECONDS, "memory_bytes": MAX_MEMORY, "output_chars": MAX_OUTPUT}}
    if not allow_execution:
        return {**base, "status": "BLOCKED", "reason": "target execution requires explicit --execute and network namespace isolation"}
    unshare = shutil.which("unshare")
    if not unshare:
        return {**base, "status": "BLOCKED", "reason": "unshare is unavailable; refusing non-isolated target execution"}
    isolated = [unshare, "--user", "--map-root-user", "--mount-proc", "--net", "--", *map(str, cmd)]
    env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "PYTHONNOUSERSITE": "1", "PYTHONDONTWRITEBYTECODE": "1"}
    try:
        p = subprocess.run(isolated, cwd=cwd, text=True, capture_output=True, timeout=MAX_SECONDS + 5,
                           preexec_fn=_limits, env=env, start_new_session=True)
        return {**base, "status": "PASS" if p.returncode == 0 else "FAILED", "exit_code": p.returncode,
                "stdout": p.stdout[-MAX_OUTPUT:], "stderr": p.stderr[-MAX_OUTPUT:]}
    except subprocess.TimeoutExpired:
        return {**base, "status": "FAILED", "reason": "timeout; process group terminated"}

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("root", type=Path)
    ap.add_argument("--output", type=Path, default=None)
    ap.add_argument("--platform", type=Path, default=None)
    ap.add_argument("--catalog-dir", type=Path, default=None)
    ap.add_argument("--execute", action="store_true", help="execute only with unshare network namespace and OS limits")
    args = ap.parse_args()
    root = args.root.resolve()
    output = (args.output or root / "artifacts" / "all-test-results.json").resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    executed, planned = {}, []

    required = ["module.yaml", "README.md", "SECURITY.md", "schemas/input.schema.json", "schemas/output.schema.json", "tests", "artifacts/traceability-matrix.json", "artifacts/policy-evaluation.json", "artifacts/test-report.json"]
    missing = [p for p in required if not (root / p).exists()]
    executed["module_inventory"] = {"status": "PASS" if not missing else "FAILED", "required": required, "missing": missing}

    json_checks = []
    for p in sorted(root.rglob("*.json")):
        if p.resolve() == output: continue
        try: json.loads(p.read_text(encoding="utf-8")); json_checks.append({"file": str(p.relative_to(root)), "status": "PASS"})
        except Exception as exc: json_checks.append({"file": str(p.relative_to(root)), "status": "FAILED", "error": str(exc)})
    executed["json_parse"] = {"status": "PASS" if all(x["status"] == "PASS" for x in json_checks) else "FAILED", "files": json_checks}

    test_files = sorted((root / "tests").glob("test_*.py")) if (root / "tests").is_dir() else []
    if test_files:
        executed["unit_tests"] = run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-p", "test_*.py"], root, args.execute)
    else:
        planned.append({"check": "unit_tests", "status": "NOT_EXECUTED", "reason": "no tests/test_*.py present"})

    evaluator = root / "policy" / "evaluate.py"
    fixtures = root / "tests" / "fixtures.json"
    if evaluator.is_file() and fixtures.is_file():
        result = run([sys.executable, str(evaluator), str(fixtures)], root, args.execute)
        if result["status"] == "PASS":
            try:
                parsed = json.loads(result["stdout"])
                if isinstance(parsed, dict):
                    result["fixture_count"] = parsed["fixture_count"]
                    result["status_counts"] = parsed["status_counts"]
                    if parsed.get("not_a_certification") is not True:
                        result["status"] = "FAILED"
                        result["parse_error"] = "not_a_certification flag missing"
                else:
                    result["fixture_count"] = len(parsed)
                    result["status_counts"] = {s: sum(1 for x in parsed if x.get("status") == s) for s in sorted({x.get("status") for x in parsed})}
            except Exception as exc:
                result["status"] = "FAILED"; result["parse_error"] = str(exc)
        executed["policy_fixtures"] = result
    else:
        planned.append({"check": "policy_fixtures", "status": "NOT_EXECUTED", "reason": "policy/evaluate.py or tests/fixtures.json missing"})

    platform = (args.platform or Path(__file__).resolve().parents[1] / "examples" / "maximal-platform" / "platform.json").resolve()
    lab = Path(__file__).resolve().parent / "run_platform_lab.py"
    if platform.is_file():
        result = run([sys.executable, str(lab), str(platform)], root, args.execute)
        if result["status"] == "PASS":
            try: result["report"] = json.loads(result["stdout"])
            except Exception: result["status"] = "FAILED"; result["parse_error"] = "platform output is not JSON"
        executed["synthetic_platform_lab"] = result
    else:
        planned.append({"check": "synthetic_platform_lab", "status": "NOT_EXECUTED", "reason": "platform fixture missing"})

    catalog = (args.catalog_dir or root / "catalog").resolve()
    validator = Path(__file__).resolve().parent / "validate_catalog.py"
    if catalog.is_dir() and list(catalog.glob("*.json")):
        result = run([sys.executable, str(validator), str(catalog), "--root", str(root)], root, args.execute)
        if result["status"] == "PASS":
            try: result["report"] = json.loads(result["stdout"])
            except Exception: result["status"] = "FAILED"; result["parse_error"] = "catalog output is not JSON"
        executed["catalog_validation"] = result
    else:
        planned.append({"check": "catalog_validation", "status": "NOT_EXECUTED", "reason": "catalog directory or manifest missing"})

    scope = [p for p in required if (root / p).exists() and (root / p).is_file()]
    inventory_hash = hashlib.sha256("\n".join(f"{p}:{hashlib.sha256((root/p).read_bytes()).hexdigest()}" for p in scope).encode()).hexdigest()
    executed["read_only_inventory"] = {"status": "PASS_WITH_LIMITATIONS" if not missing else "FAILED", "scope": scope, "inventory_hash": inventory_hash, "note": "inventory is computed without modifying source artifacts"}
    planned += [
        {"check": "independent security/domain/red-team review", "status": "NOT_EXECUTED", "reason": "requires independent reviewers"},
        {"check": "external identity-provider verification", "status": "NOT_EXECUTED", "reason": "not available in local synthetic environment"},
        {"check": "signed CI attestation", "status": "NOT_EXECUTED", "reason": "local provenance is unsigned"}
    ]
    statuses = [x.get("status") for x in executed.values()]
    overall = "FAILED" if "FAILED" in statuses else ("PASS_WITH_LIMITATIONS" if planned or "PASS_WITH_LIMITATIONS" in statuses else "PASS")
    report = {"schema":"apophis/consolidated-test-results/v1", "module_id": root.name, "generated_at": datetime.now(timezone.utc).isoformat(), "overall_verdict": overall, "not_a_certification": True, "executed": executed, "planned_not_executed": planned}
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"verdict": overall, "output": str(output), "executed_groups": len(executed), "planned_not_executed": len(planned), "not_a_certification": True}, indent=2))
    return 1 if overall == "FAILED" else 0

if __name__ == "__main__": raise SystemExit(main())
