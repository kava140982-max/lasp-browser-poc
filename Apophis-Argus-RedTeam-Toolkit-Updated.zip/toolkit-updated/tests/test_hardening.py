import json, subprocess, sys, tempfile, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUILDER = ROOT / 'builder-toolkit' / 'skill' / 'scripts'

class HardeningTests(unittest.TestCase):
    def test_duplicate_json_key_is_rejected(self):
        policy = ROOT / 'argus-100' / 'policy' / 'evaluate.py'
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'dup.json'
            p.write_text('[{"authorization_verified":true,"authorization_verified":false}]')
            r = subprocess.run([sys.executable, str(policy), str(p)], text=True, capture_output=True)
            self.assertNotEqual(r.returncode, 0)
            self.assertIn('invalid_request', r.stdout)

if __name__ == '__main__': unittest.main()
