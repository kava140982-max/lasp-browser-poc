#!/usr/bin/env python3
"""Policy note for releases: use BUILD-EXCLUDES.txt and never package source archives."""
from pathlib import Path
import fnmatch, sys
EXCLUDED = tuple(x.strip() for x in (Path(__file__).parents[1] / 'BUILD-EXCLUDES.txt').read_text().splitlines() if x.strip() and not x.startswith('#'))
def excluded(rel): return any(fnmatch.fnmatch(rel, pat) for pat in EXCLUDED)
if __name__ == '__main__':
    root=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).parents[1])
    bad=[str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and excluded(str(p.relative_to(root)))]
    print({'status':'PASS' if not bad else 'FAIL','excluded_matches':bad})
    raise SystemExit(1 if bad else 0)
