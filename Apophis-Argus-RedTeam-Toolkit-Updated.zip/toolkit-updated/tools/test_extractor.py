import io
import stat
import tempfile
import unittest
import zipfile
from pathlib import Path
from extract_archives import extract_one, safe_name

class SafeArchiveTests(unittest.TestCase):
    def test_rejects_parent_absolute_and_windows_paths(self):
        for name in ('../escape.txt','/absolute.txt','C:/outside.txt','folder/../../escape'):
            with self.subTest(name=name), self.assertRaises(ValueError): safe_name(name)
    def test_rejects_symlink_member(self):
        buf=io.BytesIO()
        with zipfile.ZipFile(buf,'w') as z:
            zi=zipfile.ZipInfo('link'); zi.external_attr=(stat.S_IFLNK|0o777)<<16; z.writestr(zi,b'target')
        with tempfile.TemporaryDirectory() as d, self.assertRaisesRegex(ValueError,'symlink forbidden'):
            extract_one(buf.getvalue(),Path(d)/'out','fixture.zip')
    def test_extracts_regular_files_without_running_them(self):
        buf=io.BytesIO()
        with zipfile.ZipFile(buf,'w') as z: z.writestr('docs/note.txt','data only')
        with tempfile.TemporaryDirectory() as d:
            entries,nested=extract_one(buf.getvalue(),Path(d)/'out','fixture.zip')
            self.assertEqual((Path(d)/'out/docs/note.txt').read_text(),'data only')
            self.assertEqual(len(entries),1); self.assertEqual(nested,[])
    def test_rejects_duplicate_paths(self):
        buf=io.BytesIO()
        with zipfile.ZipFile(buf,'w') as z:
            z.writestr('same.txt','first'); z.writestr('same.txt','second')
        with tempfile.TemporaryDirectory() as d, self.assertRaisesRegex(ValueError,'duplicate'):
            extract_one(buf.getvalue(),Path(d)/'out','fixture.zip')

if __name__=='__main__': unittest.main()
