#!/usr/bin/env python3
"""Read-only internal consistency audit for unpacked Apophis bundle roots.
Does not execute source scripts and cannot authenticate who created the hashes.
"""
from __future__ import annotations
import argparse, hashlib, json, re, stat
from pathlib import Path, PurePosixPath

def sha(p:Path)->str: return hashlib.sha256(p.read_bytes()).hexdigest()
def safe_file(root:Path, rel:str)->Path:
    q=PurePosixPath(rel.replace('\\','/'))
    if q.is_absolute() or any(x in ('..','') for x in q.parts): raise ValueError(f'unsafe path: {rel!r}')
    candidate=root.joinpath(*q.parts)
    cursor=root
    for part in q.parts:
        cursor=cursor/part
        if cursor.is_symlink(): raise ValueError(f'symlink path component: {rel!r}')
    p=candidate.resolve()
    if not p.is_relative_to(root.resolve()) or not p.is_file(): raise ValueError(f'not a regular in-scope file: {rel!r}')
    return p

def audit(root:Path)->dict:
    root=root.resolve(); result={'root_name':root.name,'manifest_status':'NOT_PRESENT','manifest_entries':0,'manifest_passed':0,'manifest_failures':[],'sha256sums_status':'NOT_PRESENT','sha256sums_entries':0,'sha256sums_passed':0,'sha256sums_failures':[],'execution':'NOT_PERFORMED','interpretation':'Internal byte consistency only; unsigned checksums do not prove origin or safety.'}
    mp=root/'MANIFEST.json'
    if mp.exists():
        m=json.loads(mp.read_text(encoding='utf-8')); entries=m.get('source_files',m.get('files',[])); result['manifest_entries']=len(entries); failures=[]
        for item in entries:
            rel=item.get('path'); expected_size=item.get('size_bytes',item.get('bytes',item.get('size'))); expected_hash=item.get('sha256')
            try:
                f=safe_file(root,rel); raw=f.read_bytes()
                if expected_size is not None and len(raw)!=expected_size: failures.append({'path':rel,'error':'size_mismatch'})
                elif not expected_hash or hashlib.sha256(raw).hexdigest()!=expected_hash: failures.append({'path':rel,'error':'sha256_mismatch'})
                else: result['manifest_passed']+=1
            except Exception as e: failures.append({'path':rel,'error':str(e)})
        result['manifest_failures']=failures; result['manifest_status']='PASS' if not failures and result['manifest_passed']==len(entries) else 'FAIL'
        result['manifest_claims']={'bundle':m.get('bundle'),'created_utc':m.get('created_utc'),'status':m.get('status'),'not_a_certification':m.get('not_a_certification')}
    sums=root/'SHA256SUMS'
    if sums.exists():
        failures=[]; entries=[]
        for line_no,line in enumerate(sums.read_text(encoding='utf-8').splitlines(),1):
            if not line.strip(): continue
            m=re.fullmatch(r'([0-9a-fA-F]{64})  (.+)',line)
            if not m: failures.append({'line':line_no,'error':'malformed_checksum_line'}); continue
            expected,rel=m.groups(); entries.append(rel)
            try:
                f=safe_file(root,rel)
                if sha(f)!=expected.lower(): failures.append({'path':rel,'error':'sha256_mismatch'})
                else: result['sha256sums_passed']+=1
            except Exception as e: failures.append({'path':rel,'error':str(e)})
        result['sha256sums_entries']=len(entries); result['sha256sums_failures']=failures; result['sha256sums_status']='PASS' if not failures and len(entries)==result['sha256sums_passed'] else 'FAIL'
    # Builder toolkit has a structured JSON checksum inventory rather than a root SHA256SUMS file.
    nested_manifest=root/'SHA256SUMS.json'
    if nested_manifest.exists():
        m=json.loads(nested_manifest.read_text(encoding='utf-8')); entries=m.get('files',[]); failures=[]; passed=0
        for item in entries:
            rel=item.get('path'); expected_size=item.get('bytes'); expected_hash=item.get('sha256')
            try:
                f=safe_file(root,rel); raw=f.read_bytes()
                if len(raw)!=expected_size or hashlib.sha256(raw).hexdigest()!=expected_hash: failures.append({'path':rel,'error':'size_or_hash_mismatch'})
                else: passed+=1
            except Exception as e: failures.append({'path':rel,'error':str(e)})
        result['nested_checksum_json']={'status':'PASS' if not failures and passed==len(entries) else 'FAIL','entries':len(entries),'passed':passed,'failures':failures,'signed':m.get('signed'),'not_a_certification':m.get('not_a_certification')}
    return result

def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('roots',nargs='+',type=Path); p.add_argument('--output',type=Path,required=True); a=p.parse_args()
    report={'schema_version':'argus-source-audit/v1','archives':[audit(r) for r in a.roots],'executed_source_code':False}
    a.output.parent.mkdir(parents=True,exist_ok=True); a.output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps({"output":str(a.output),"roots":[{"root":x['root_name'],"manifest":x['manifest_status'],"checksums":x['sha256sums_status'],"nested":x.get('nested_checksum_json',{}).get('status')} for x in report['archives']]},ensure_ascii=False))
    return 1 if any(x['manifest_status']=='FAIL' or x['sha256sums_status']=='FAIL' or x.get('nested_checksum_json',{}).get('status')=='FAIL' for x in report['archives']) else 0
if __name__=='__main__': raise SystemExit(main())
