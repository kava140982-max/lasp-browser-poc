import json
import tempfile
import unittest
from pathlib import Path
from knowledge import append_one, read_store

class PatternLedgerTests(unittest.TestCase):
    def item(self, pattern_id='PAT-0001'):
        return {"pattern_id":pattern_id,"title":"Test pattern","pattern":"Fail closed on missing evidence.","lesson":"Do not infer success.","evidence_class":"observed","claim_status":"observed","source_refs":["source/test.md"],"tags":["test"]}
    def test_append_and_verify_chain(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'patterns.jsonl'; append_one(self.item(),p); append_one(self.item('PAT-0002'),p)
            rows=read_store(p); self.assertEqual(len(rows),2); self.assertEqual(rows[1]['previous_hash'],rows[0]['record_hash'])
    def test_duplicate_id_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'patterns.jsonl'; append_one(self.item(),p)
            with self.assertRaises(ValueError): append_one(self.item(),p)
    def test_tamper_detected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'patterns.jsonl'; append_one(self.item(),p)
            row=json.loads(p.read_text()); row['lesson']='changed'; p.write_text(json.dumps(row)+'\n')
            with self.assertRaisesRegex(ValueError,'hash mismatch'): read_store(p)
    def test_record_byte_limit(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'patterns.jsonl'; item=self.item(); item['lesson']='x'*70000
            with self.assertRaisesRegex(ValueError,'64 KiB'): append_one(item,p)
    def test_evidence_class_allowlist(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'patterns.jsonl'; item=self.item(); item['evidence_class']='CERTIFIED'
            with self.assertRaisesRegex(ValueError,'unsupported evidence class'): append_one(item,p)

if __name__=='__main__': unittest.main()
