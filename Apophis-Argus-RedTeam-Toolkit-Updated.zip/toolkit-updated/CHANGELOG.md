# Changelog

## 2026-10-23 — Security regression update

- Originalpaket: `Apophis-Argus-RedTeam-Toolkit-Hardened.zip`, unverändert, SHA-256 `e43427a8a557e2413a0074753c8c9e9ffd8dd1ac9e3bab4911606bd405f9d541`.
- `builder-toolkit/SKILL.md` verlinkt jetzt den Zusatzleitfaden `builder-toolkit/skill/references/red-team-remediation-and-mutations.md` für API-/Autorisierungsbefunde und Folgemutationen.
- Zusatzleitfaden bewahrt den konkret entdeckten Rathaus-OS-Fall als wiederverwendbare, begrenzte Root-Cause-Lektion: Route vor Auth-Gate, globale Eingabefeld-Allowlist für public und internal, doppelte JSON-Schlüssel.
- Für Folge-Builds verbindlich: jede Route/HTTP-Methode auf Zugriff prüfen; öffentliche und interne DTOs getrennt geschlossen definieren; Schlüssel-/Status-/Typüberschreibung mutieren; historische Entdeckungsweise, Quellhash, Fixstatus und Regressionstest in einem persistenten Befund-Ledger behalten.
- Die drei neuen Kontrollen wurden in `RELEASE-MANIFEST.json` deklarativ ergänzt. Das Manifest/ZIP dieses Updated-Pakets sind nach den Dateiänderungen neu zu erstellen und separat zu verifizieren.
- Alle Beispiele verlangen lokale synthetische Tests. Keine Zertifizierungs-, Compliance- oder Produktionsfreigabe wird behauptet.
